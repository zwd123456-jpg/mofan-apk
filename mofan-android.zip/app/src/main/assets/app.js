/* 《限制级末日症候》· 视觉小说
 * 主角（高川）第一人称视角的单线阅读：不做数值、不做分支、不做选择。
 * 演出元素：章节卡 / 对话立绘 / 魔纹鉴定面板 / 冲击帧 / 关键物 / 画面效果。
 * 便利功能：自动播放、快进已读、回看、章节跳转、名场面回想、存档读档。
 */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };
  var TOC = window.TOC || { volumes: [], chapters: [], beats: [] };
  var CAST = window.CAST || {};
  var PROTAG = "高川";

  var PREF = "mofan-vn-pref";
  var POS = "mofan-vn-pos";
  var SAVEK = "mofan-vn-saves";

  var S = {
    vol: 1, i: 0, maxRead: 0,
    auto: false, showName: true, typewriter: true, cast: true, sound: true,
    speed: 42, size: 20, line: 190, theme: "ink"
  };

  var DATA = null, NODES = [], CHAPS = [], META = {};
  var timer = null, typeTimer = null, toastTimer = null, idTimers = [];
  var historyBuf = [];
  var onStage = [];

  /* ================= 小工具 ================= */
  function vkey(n) { return "vol" + (n < 10 ? "0" : "") + n; }
  function readKey(v) { return "mofan-vn-read-" + v; }
  function colorOf(n) { return (CAST[n] && CAST[n].c) || "#9a9287"; }
  function hasSprite(n) { return !!(CAST[n] && CAST[n].s); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  /* ================= 改写 / 更新接口（patch 层） =================
   * 三层覆盖，优先级从低到高：
   *   ① build.py 切出来的原始数据        assets/volNN.js
   *   ② window.PATCH  由 spec/patch.json 发射 —— 人工/AI 直接改文本文件
   *   ③ localStorage  游戏内「改写」面板改的（mofan-vn-edit）
   * 改文案 / 改说话人 / 取消大字特写 都只改字段，不动节点数量，
   * 所以存档（存的是下标）不会错位；只有 drop / insert 会改变长度，
   * 那会顺手清掉「上次阅读位置」，避免跳错。
   */
  var PATCH = window.PATCH || {};
  var EDIT_KEY = "mofan-vn-edit";
  var PATCHED = {};

  function getEdits() {
    try { return JSON.parse(localStorage.getItem(EDIT_KEY) || "{}"); } catch (e) { return {}; }
  }
  function putEdits(o) {
    try { localStorage.setItem(EDIT_KEY, JSON.stringify(o)); }
    catch (e) { toast("改写存不进去（浏览器存储被禁）"); }
  }
  function rulesFor(vk) {
    var e = getEdits();
    return [].concat(PATCH["*"] || [], PATCH[vk] || [], e[vk] || []);
  }
  function targetsOf(nodes, r) {
    var out = [];
    // 带 x0（原文快照）的规则优先按原文定位，防止重新切页后下标漂移
    if (r.x0 !== undefined) {
      for (var k = 0; k < nodes.length; k++) {
        if (nodes[k].x === r.x0) out.push(k);
      }
      if (out.length) return out;
    }
    if (r.at !== undefined) {
      var j = parseInt(r.at, 10);
      if (!isNaN(j) && j >= 0 && j < nodes.length) out.push(j);
      return out;
    }
    if (r.find) {
      for (var i = 0; i < nodes.length; i++) {
        if (String(nodes[i].x || "").indexOf(r.find) >= 0) out.push(i);
      }
    }
    return out;
  }
  function applyPatch(vk, nodes) {
    if (PATCHED[vk]) return nodes;
    PATCHED[vk] = true;
    var rules = rulesFor(vk);
    if (!rules.length) return nodes;
    var structural = false;
    rules.forEach(function (r) {
      if (!r || !r.op) return;
      var tg = targetsOf(nodes, r);
      if (!tg.length) return;
      if (r.op === "drop" || r.op === "insert") {
        structural = true;
        tg.slice().sort(function (a, b) { return b - a; }).forEach(function (j) {
          if (r.op === "drop") nodes.splice(j, 1);
          else if (r.node) nodes.splice(j + 1, 0, JSON.parse(JSON.stringify(r.node)));
        });
        return;
      }
      tg.forEach(function (j) {
        var n = nodes[j];
        if (!n) return;
        if (r.op === "demote") { if (n.t === "m") n.t = "n"; }
        else if (r.op === "promote") { if (n.t === "n") n.t = "m"; }
        else if (r.op === "replace") {
          if (r.from && String(n.x || "").indexOf(r.from) >= 0) {
            n.x = String(n.x).split(r.from).join(r.to === undefined ? "" : r.to);
          }
        }
        else if (r.op === "fx") {
          if (r.e === null || r.e === "") delete n.e; else n.e = r.e;
        }
        else if (r.op === "set") {
          var src = (typeof r.set === "object" && r.set) ? r.set : r;
          ["t", "x", "w", "g", "sub", "mood", "e"].forEach(function (k) {
            if (src[k] !== undefined && ["op", "at", "find", "note", "x0"].indexOf(k) < 0) {
              if (src[k] === null || src[k] === "") delete n[k]; else n[k] = src[k];
            }
          });
        }
      });
    });
    if (structural) { try { localStorage.removeItem(POS); } catch (e) {} }
    return nodes;
  }
  function saveEdit(vk, idx, fields, x0) {
    var e = getEdits();
    var list = (e[vk] || []).filter(function (r) {
      return !(r.at === idx && (r.x0 === x0 || (r.x0 === undefined && r.at === idx)));
    });
    list.push({ at: idx, x0: x0, op: "set", set: fields });
    e[vk] = list;
    putEdits(e);
  }
  function clearEdits(vk) {
    var e = getEdits();
    if (vk) delete e[vk]; else e = {};
    putEdits(e);
    PATCHED = {};
  }
  function countEdits() {
    var e = getEdits(), n = 0;
    Object.keys(e).forEach(function (k) { n += (e[k] || []).length; });
    return n;
  }

  function toast(msg) {
    var t = $("toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove("show"); }, 2000);
  }

  /* ================= 音效 ================= */
  var AC = null;
  function actx() {
    if (!AC) {
      try { AC = new (window.AudioContext || window.webkitAudioContext)(); }
      catch (e) { AC = null; }
    }
    if (AC && AC.state === "suspended") { try { AC.resume(); } catch (e) {} }
    return AC;
  }
  function beep(freq, dur, type, gain) {
    if (!S.sound) return;
    var a = actx(); if (!a) return;
    try {
      var o = a.createOscillator(), g = a.createGain();
      o.type = type || "sine";
      o.frequency.value = freq || 440;
      o.connect(g); g.connect(a.destination);
      var t = a.currentTime, d = dur || 0.1;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(gain || 0.045, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.start(t); o.stop(t + d + 0.03);
      o.onended = function () { try { o.disconnect(); } catch (e) {} try { g.disconnect(); } catch (e) {} };
    } catch (e) {}
  }
  function thud() {
    if (!S.sound) return;
    var a = actx(); if (!a) return;
    try {
      var len = Math.floor(a.sampleRate * 0.22);
      var buf = a.createBuffer(1, len, a.sampleRate);
      var ch = buf.getChannelData(0);
      for (var i = 0; i < len; i++) ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.4);
      var src = a.createBufferSource(), g = a.createGain(), f = a.createBiquadFilter();
      src.buffer = buf; f.type = "lowpass"; f.frequency.value = 420;
      g.gain.value = 0.16;
      src.connect(f); f.connect(g); g.connect(a.destination);
      src.start();
    } catch (e) {}
  }
  var _sndT = 0;
  function sndAdvance() {
    var now = (window.performance && performance.now) ? performance.now() : Date.now();
    if (now - _sndT < 110) return;   /* 60Hz 下每 3 字一次 -> 最多 ~9 次/秒，这里压到 ~9/s 且去抖 */
    _sndT = now;
    beep(660, 0.05, "triangle", 0.028);
  }
  function sndPage() { beep(392, 0.09, "sine", 0.03); }
  function sndIdent() { beep(1180, 0.06, "square", 0.022); }
  function sndShake() { thud(); }
  function sndFlash() { beep(1560, 0.16, "sine", 0.035); }
  function sndDark() { beep(120, 0.4, "sine", 0.05); }
  function sndBlood() { beep(90, 0.3, "sawtooth", 0.04); thud(); }

  /* ================= 立绘（参数化剪影） ================= */
  /* 立绘参数。优先用 assets/sprites.js（由 spec/sprites.json 生成），
     没读到就退回这份内置表。 */
  var SP = (window.SPRITE_PARAM && Object.keys(window.SPRITE_PARAM).length)
    ? window.SPRITE_PARAM
    : {
      "富江": { r: 17, sh: 36, hair: 2, low: "skirt" },
      "席森": { r: 18, sh: 50, hair: 0, low: "robe", acc: "hood" },
      "卡门": { r: 18, sh: 44, hair: 1, low: "coat", acc: "hat" },
      "阮黎": { r: 17, sh: 40, hair: 2, low: "coat" },
      "走火": { r: 17, sh: 42, hair: 0, low: "coat" },
      "锉刀": { r: 19, sh: 58, hair: 0, low: "pants" },
      "八景": { r: 17, sh: 38, hair: 2, low: "robe" },
      "桃乐丝": { r: 16, sh: 34, hair: 3, low: "skirt" },
      "咲夜": { r: 17, sh: 36, hair: 2, low: "skirt" },
      "同桌": { r: 18, sh: 44, hair: 0, low: "pants" },
      "崔蒂": { r: 17, sh: 38, hair: 4, low: "skirt" }
    };
  var HAIRS = [0, 1, 2, 3, 4];
  var LOWS = ["skirt", "pants", "robe", "coat"];

  function param(name) {
    if (SP[name]) return SP[name];
    var h = 0, i;
    for (i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
    return {
      r: 16 + (h % 4),
      sh: 36 + (h >> 2) % 5 * 5,
      hair: HAIRS[(h >> 5) % 5],
      low: LOWS[(h >> 8) % 4]
    };
  }

  function spriteSVG(name) {
    var p = param(name), r = p.r, sh = p.sh, s = "";
    var hy = 50, sy = hy + r + 8, wy = sy + 58, foot = 302;
    var L = 60 - sh / 2, R = 60 + sh / 2;

    /* 后层头发 */
    if (p.hair === 2) {
      s += '<path d="M' + (60 - r - 4) + ' ' + (hy - 2) +
           ' C ' + (58 - r) + ' ' + (hy + r * 3) + ', ' + (58 - r) + ' ' + (hy + r * 5) +
           ', ' + (60 - r + 2) + ' ' + (wy - 4) +
           ' L ' + (60 + r - 2) + ' ' + (wy - 4) +
           ' C ' + (62 + r) + ' ' + (hy + r * 5) + ', ' + (62 + r) + ' ' + (hy + r * 3) +
           ', ' + (60 + r + 4) + ' ' + (hy - 2) + ' Z"/>';
    } else if (p.hair === 3) {
      s += '<path d="M' + (60 - r - 4) + ' ' + (hy + 2) + ' q -16 8 -13 34 q 3 26 12 44 q -11 -38 -9 -78 Z"/>';
      s += '<path d="M' + (60 + r + 4) + ' ' + (hy + 2) + ' q 16 8 13 34 q -3 26 -12 44 q 11 -38 9 -78 Z"/>';
    } else if (p.hair === 4) {
      s += '<circle cx="60" cy="' + hy + '" r="' + (r + 8) + '" opacity=".6"/>';
    } else if (p.hair === 1) {
      s += '<path d="M' + (60 - r - 2) + ' ' + (hy - 2) + ' q -3 ' + (r * 2) + ' -1 ' + (r * 3.4) +
           ' l ' + (2 * r + 6) + ' 0 q 2 -' + (r * 1.4) + ' -1 -' + (r * 3.4) + ' Z"/>';
    }

    /* 头 + 颈 */
    s += '<circle cx="60" cy="' + hy + '" r="' + r + '"/>';
    s += '<rect x="' + (60 - r * 0.26) + '" y="' + (hy + r - 2) + '" width="' + (r * 0.52) + '" height="14"/>';

    /* 帽 / 兜帽 */
    if (p.acc === "hat") {
      s += '<path d="M' + (60 - r - 12) + ' ' + (hy - r + 6) + ' h ' + (2 * r + 24) + ' v5 h -' + (2 * r + 24) + ' Z"/>';
      s += '<path d="M' + (60 - r - 3) + ' ' + (hy - r + 6) + ' q ' + (r + 3) + ' -26 ' + (2 * r + 6) + ' 0 Z"/>';
    } else if (p.acc === "hood") {
      s += '<path d="M' + (60 - r - 7) + ' ' + (hy + r + 4) +
           ' q -2 -' + (r * 2.6) + ' ' + (r + 7) + ' -' + (r * 2.6) +
           ' q ' + (r + 7) + ' 0 ' + (r + 7) + ' ' + (r * 2.6) + ' Z"/>';
    }

    /* 躯干 */
    s += '<path d="M' + L + ' ' + sy + ' Q 60 ' + (sy - 9) + ' ' + R + ' ' + sy +
         ' L ' + (60 + sh * 0.36) + ' ' + wy + ' L ' + (60 - sh * 0.36) + ' ' + wy + ' Z"/>';
    /* 手臂 */
    s += '<path d="M' + L + ' ' + sy + ' q -9 46 -3 86 l 13 0 q -7 -42 2 -86 Z"/>';
    s += '<path d="M' + R + ' ' + sy + ' q 9 46 3 86 l -13 0 q 7 -42 -2 -86 Z"/>';

    /* 腿（先画，再用裙/袍盖住） */
    var lh = foot - wy;
    s += '<path d="M' + (60 - sh * 0.30) + ' ' + wy + ' l -5 ' + lh + ' h ' + (sh * 0.30) +
         ' l 3 -' + lh + ' Z"/>';
    s += '<path d="M' + (60 + sh * 0.30) + ' ' + wy + ' l 5 ' + lh + ' h -' + (sh * 0.30) +
         ' l -3 -' + lh + ' Z"/>';

    /* 下身 */
    if (p.low === "skirt") {
      s += '<path d="M' + (60 - sh * 0.36) + ' ' + wy +
           ' L ' + (60 - sh * 0.78) + ' ' + (wy + 96) +
           ' q ' + (sh * 0.78) + ' 16 ' + (sh * 1.56) + ' 0' +
           ' L ' + (60 + sh * 0.36) + ' ' + wy + ' Z"/>';
    } else if (p.low === "robe") {
      s += '<path d="M' + (60 - sh * 0.36) + ' ' + wy +
           ' L ' + (60 - sh * 0.84) + ' ' + (foot + 4) +
           ' q ' + (sh * 0.84) + ' 13 ' + (sh * 1.68) + ' 0' +
           ' L ' + (60 + sh * 0.36) + ' ' + wy + ' Z"/>';
    } else if (p.low === "coat") {
      s += '<path d="M' + (60 - sh * 0.36) + ' ' + wy +
           ' L ' + (60 - sh * 0.74) + ' ' + (foot - 8) +
           ' q ' + (sh * 0.74) + ' 11 ' + (sh * 1.48) + ' 0' +
           ' L ' + (60 + sh * 0.36) + ' ' + wy + ' Z"/>';
    }
    return '<svg viewBox="0 0 120 320" preserveAspectRatio="xMidYMax meet"><g fill="currentColor">' + s + '</g></svg>';
  }

  function renderCast(speaker) {
    var box = $("cast");
    if (!S.cast) { box.innerHTML = ""; return; }
    var kids = Array.prototype.slice.call(box.children);
    kids.forEach(function (el) {
      if (onStage.indexOf(el.getAttribute("data-n")) < 0) {
        el.classList.add("out");
        setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 420);
      }
    });
    onStage.forEach(function (n) {
      var el = box.querySelector('[data-n="' + n + '"]');
      if (!el) {
        el = document.createElement("div");
        el.className = "cast-fig enter";
        el.setAttribute("data-n", n);
        el.style.setProperty("--cc", colorOf(n));
        el.innerHTML = spriteSVG(n);
        var lab = document.createElement("div");
        lab.className = "cast-nm";
        lab.textContent = n;
        el.appendChild(lab);
        box.appendChild(el);
        requestAnimationFrame(function () { el.classList.remove("enter"); });
      }
      el.classList.toggle("talk", n === speaker);
    });
  }
  function pushCast(name) {
    if (!name || name === PROTAG) return;
    var k = onStage.indexOf(name);
    if (k >= 0) onStage.splice(k, 1);
    onStage.push(name);
    while (onStage.length > 3) onStage.shift();
  }

  /* ================= 存档 / 偏好 ================= */
  function loadPref() {
    try {
      var o = JSON.parse(localStorage.getItem(PREF) || "{}");
      ["showName", "typewriter", "cast", "sound", "speed", "size", "line", "theme"]
        .forEach(function (k) { if (o[k] !== undefined) S[k] = o[k]; });
    } catch (e) {}
  }
  function savePref() {
    try {
      localStorage.setItem(PREF, JSON.stringify({
        showName: S.showName, typewriter: S.typewriter, cast: S.cast, sound: S.sound,
        speed: S.speed, size: S.size, line: S.line, theme: S.theme
      }));
    } catch (e) {}
  }
  function savePos() {
    var ch = curChapter();
    try {
      localStorage.setItem(POS, JSON.stringify({
        vol: S.vol, i: S.i,
        ch: ch ? ch.no : 0, chTitle: ch ? ch.title : ""
      }));
    } catch (e) {}
    try { localStorage.setItem(readKey(S.vol), String(S.maxRead)); } catch (e) {}
  }
  function getSaves() {
    try { return JSON.parse(localStorage.getItem(SAVEK) || "[]"); } catch (e) { return []; }
  }
  function putSaves(a) {
    try { localStorage.setItem(SAVEK, JSON.stringify(a)); } catch (e) { toast("存不进去（浏览器存储被禁）"); }
  }

  /* ================= 卷数据 ================= */
  function useVol(n) {
    var d = (window.STORY || {})[vkey(n)];
    if (!d) return false;
    DATA = d; NODES = applyPatch(vkey(n), d.nodes); CHAPS = d.chapters; META = d.meta;
    S.vol = n;
    S.maxRead = 0;
    try { S.maxRead = parseInt(localStorage.getItem(readKey(n)) || "0", 10) || 0; } catch (e) {}
    onStage = []; renderCast(null);
    return true;
  }
  function ensureVol(n, cb) {
    if ((window.STORY || {})[vkey(n)]) { useVol(n); cb && cb(); return; }
    var s = document.createElement("script");
    s.src = "assets/" + vkey(n) + ".js";
    s.onload = function () { useVol(n); cb && cb(); };
    s.onerror = function () { toast("assets/" + vkey(n) + ".js 没读到"); };
    document.head.appendChild(s);
  }

  /* ================= 设置 ================= */
  function applySet() {
    document.documentElement.style.setProperty("--size", S.size + "px");
    document.documentElement.style.setProperty("--line-h", S.line + "%");
    document.body.className = "theme-" + S.theme;
    $("s-size").value = S.size; $("v-size").textContent = S.size + "px";
    $("s-line").value = S.line; $("v-line").textContent = (S.line / 100).toFixed(2);
    $("s-speed").value = S.speed; $("v-speed").textContent = S.speed + " 字/秒";
    $("s-type").checked = S.typewriter;
    $("s-name").checked = S.showName;
    $("s-cast").checked = S.cast;
    $("s-sound").checked = S.sound;
  }

  /* ================= 渲染一页 ================= */
  function render(at) {
    if (!NODES.length) return;
    if (at < 0) at = 0;
    if (at >= NODES.length) at = NODES.length - 1;
    stopType(); clearIdTimers();
    S.i = at;
    if (at > S.maxRead) S.maxRead = at;

    var n = NODES[at];
    hideChapter(); hideProp(); hideFlash(); hideIdent();
    $("nextmark").classList.remove("show");

    if (n.t === "c") {
      if (n.mood) setMood(n.mood);
      onStage = []; renderCast(null);
      showChapter(n); sndPage();
    } else if (n.t === "p") {
      showProp(n); beep(880, 0.14, "sine", 0.03);
    } else if (n.t === "m") {
      showFlash(n.x);                    /* 大字卡本身就是演出，不再无条件震屏 */
      if (n.e) fx(n.e); else sndPage();
    } else if (n.t === "i") {
      showIdent(n.x);
    } else {
      var sp = (n.t === "d") ? n.w : null;
      pushCast(sp);
      renderCast(sp);
      if (n.e) fx(n.e);
      renderLine(n);
    }
    updateChrome();
    savePos();
  }

  function renderLine(n) {
    var plate = $("nameplate"), nm = $("name");
    if (n.t === "d" && S.showName && n.w && n.w !== PROTAG) {
      nm.textContent = n.w;
      nm.style.color = colorOf(n.w);
      nm.style.borderLeftColor = colorOf(n.w);
      plate.style.visibility = "visible";
    } else {
      nm.textContent = ""; plate.style.visibility = "hidden";
    }
    var txt = n.t === "d" ? "「" + n.x + "」" : n.x;
    if (S.typewriter) typeOut(txt);
    else { $("text").textContent = txt; $("nextmark").classList.add("show"); }
    if (n.t === "d" && n.w && n.w !== PROTAG) beep(520 + (n.w.charCodeAt(0) % 9) * 26, 0.05, "triangle", 0.024);
    historyBuf.push(n);
    if (historyBuf.length > 240) historyBuf.shift();
  }

  function typeOut(txt) {
    var box = $("text"), t0 = 0, shown = -1, full = String(txt || "");
    stopType();
    box.textContent = "";
    S.typing = true;
    $("nextmark").classList.remove("show");
    function tick(now) {
      if (!S.typing) return;
      if (!t0) t0 = now;
      var k = Math.floor((now - t0) * S.speed / 1000);
      if (k > full.length) k = full.length;
      if (k !== shown) {
        shown = k;
        box.textContent = full.slice(0, k);
        if (k % 3 === 0) sndAdvance();
      }
      if (k >= full.length) { stopType(); $("nextmark").classList.add("show"); return; }
      typeTimer = requestAnimationFrame(tick);
    }
    typeTimer = requestAnimationFrame(tick);
  }
  function stopType() {
    if (typeTimer && typeof cancelAnimationFrame === "function") { try { cancelAnimationFrame(typeTimer); } catch (e) {} }
    typeTimer = null; S.typing = false;
  }
  function finishType() {
    stopType();
    var n = NODES[S.i];
    if (n && (n.t === "n" || n.t === "d")) {
      $("text").textContent = n.t === "d" ? "「" + n.x + "」" : n.x;
    }
    S.typing = false;
    $("nextmark").classList.add("show");
  }

  /* ---------- 章节卡 ---------- */
  function showChapter(n) {
    $("ch-no").textContent = n.sub ? n.x : (META.volume || "");
    $("ch-title").textContent = n.sub || n.x;
    $("chapter").classList.remove("hide");
    $("textbox").style.display = "none";
  }
  function hideChapter() { $("chapter").classList.add("hide"); $("textbox").style.display = ""; }

  /* ---------- 关键物 ---------- */
  function showProp(n) {
    $("prop-art").innerHTML = '<svg viewBox="0 0 100 100"><use href="#p-' + n.g + '"></use></svg>';
    $("prop-name").textContent = n.x;
    $("prop").classList.remove("hide");
    $("textbox").style.display = "none";
    var at = S.i;
    clearTimeout(timer);
    timer = setTimeout(function () {
      if (S.i !== at) return;
      if (S.i < NODES.length - 1) render(S.i + 1);
    }, 1800);
  }
  function hideProp() { $("prop").classList.add("hide"); $("textbox").style.display = ""; }

  /* ---------- 冲击帧 ---------- */
  function showFlash(txt) {
    $("flash-text").textContent = txt;
    $("flash").classList.remove("hide");
    $("textbox").style.display = "none";
  }
  function hideFlash() { $("flash").classList.add("hide"); $("textbox").style.display = ""; }

  /* ---------- 魔纹鉴定 ---------- */
  function clearIdTimers() { idTimers.forEach(clearTimeout); idTimers = []; }
  function showIdent(rows) {
    var box = $("id-rows");
    box.innerHTML = "";
    $("ident").classList.remove("hide");
    $("textbox").style.display = "none";
    rows.forEach(function (line, k) {
      var d = document.createElement("div");
      d.className = "id-row";
      var m = /^([^：:]+)[：:]\s*(.*)$/.exec(line);
      if (m) {
        var a = document.createElement("span"); a.className = "id-k"; a.textContent = m[1];
        var b = document.createElement("span"); b.className = "id-v"; b.textContent = m[2];
        d.appendChild(a); d.appendChild(b);
      } else {
        d.textContent = line;
      }
      box.appendChild(d);
      idTimers.push(setTimeout(function () { d.classList.add("on"); sndIdent(); }, 120 + k * 150));
    });
  }
  function hideIdent() { clearIdTimers(); $("ident").classList.add("hide"); $("textbox").style.display = ""; }

  /* ---------- 画面效果 ---------- */
  function fx(kind) {
    var st = $("stage"), fl = $("fxlayer");
    fl.className = "";
    if (kind === "shake") {
      st.classList.remove("fx-shake");
      void st.offsetWidth;
      st.classList.add("fx-shake");
      setTimeout(function () { st.classList.remove("fx-shake"); }, 620);
      sndShake();
    } else if (kind === "flash") {
      fl.classList.add("fx-flash");
      setTimeout(function () { fl.classList.remove("fx-flash"); }, 700);
      sndFlash();
    } else if (kind === "dark") {
      fl.classList.add("fx-dark");
      setTimeout(function () { fl.classList.remove("fx-dark"); }, 1100);
      sndDark();
    } else if (kind === "blood") {
      fl.classList.add("fx-blood");
      st.classList.remove("fx-shake"); void st.offsetWidth; st.classList.add("fx-shake");
      setTimeout(function () { fl.classList.remove("fx-blood"); st.classList.remove("fx-shake"); }, 900);
      sndBlood();
    }
  }

  /* ---------- 氛围 ---------- */
  var curMood = "";
  function setMood(m) {
    if (curMood === m) return;
    curMood = m;
    var box = $("mood");
    box.setAttribute("data-mood", m);
    box.style.opacity = 0;
    setTimeout(function () {
      box.innerHTML = '<svg viewBox="0 0 200 120"><use href="#m-' + m + '"></use></svg>';
      box.style.opacity = 1;
    }, 260);
  }

  /* ---------- 顶栏 / 进度 ---------- */
  function curChapter() {
    var c = null;
    for (var i = 0; i < CHAPS.length; i++) { if (CHAPS[i].at <= S.i) c = CHAPS[i]; else break; }
    return c;
  }
  function updateChrome() {
    var ch = curChapter();
    $("tb-vol").textContent = META.volume || "";
    $("tb-ch").textContent = ch ? ("第 " + ch.no + " 章 · " + ch.title) : "";
    $("progress-bar").style.width = (NODES.length ? ((S.i + 1) / NODES.length * 100) : 0) + "%";
  }

  /* ================= 推进 ================= */
  function advance() {
    if (!NODES.length) return;
    if (S.typing) { finishType(); return; }
    if (S.i >= NODES.length - 1) {
      toggleAuto(false);
      var nx = S.vol + 1;
      if (nx <= 12) toast("本卷读完 —— 从顶部菜单可进入第 " + nx + " 卷");
      else toast("全书读完。");
      return;
    }
    render(S.i + 1);
    if (S.auto) scheduleAuto();
  }
  function back() { if (S.i > 0) render(S.i - 1); }

  function skipRead() {
    if (!NODES.length) return;
    var guard = 0, hit = false;
    while (S.i < NODES.length - 1 && guard < 5000) {
      S.i++; guard++;
      var n = NODES[S.i];
      if (n.t === "m" || n.t === "i" || n.t === "c" || n.t === "p") { hit = true; break; }
      if (S.i > S.maxRead) { hit = true; break; }
    }
    stopType();
    render(S.i);
    toast(hit ? "快进到此处" : "已经读到最新");
  }

  function scheduleAuto() {
    clearTimeout(timer);
    var n = NODES[S.i];
    var base = (n && (n.t === "d" || n.t === "n"))
      ? Math.max(1100, n.x.length / S.speed * 1000 + 900)
      : (n && n.t === "c") ? 2800 : 1900;
    timer = setTimeout(function () { if (S.auto) advance(); }, base);
  }
  function toggleAuto(on) {
    S.auto = (on === undefined) ? !S.auto : on;
    $("btn-auto").classList.toggle("on", S.auto);
    var a = $("mb-auto"); if (a) a.classList.toggle("on", S.auto);
    if (S.auto) { scheduleAuto(); toast("自动播放：开"); }
    else { clearTimeout(timer); toast("自动播放：关"); }
  }

  /* ================= 面板 ================= */
  function openLog() {
    var b = $("log-body"); b.innerHTML = "";
    var start = Math.max(0, historyBuf.length - 140);
    for (var i = start; i < historyBuf.length; i++) {
      var n = historyBuf[i];
      var d = document.createElement("div");
      d.className = "log-line" + (n.t === "m" ? " flash" : "") +
                    (n.t === "i" ? " ident" : "") + (i === historyBuf.length - 1 ? " cur" : "");
      if (n.t === "d") {
        var s = document.createElement("span");
        s.className = "who";
        s.textContent = n.w || "？";
        s.style.color = colorOf(n.w);
        d.appendChild(s);
      }
      d.appendChild(document.createTextNode(
        n.t === "d" ? "「" + n.x + "」" : (n.t === "i" ? "【鉴定】" + n.x.join(" / ") : n.x)));
      b.appendChild(d);
    }
    $("logpanel").classList.remove("hide");
    b.scrollTop = b.scrollHeight;
  }

  function buildVolTabs(box) {
    box.innerHTML = "";
    (TOC.volumes || []).forEach(function (v) {
      var d = document.createElement("button");
      d.className = "voltab" + (v.no === S.vol ? " on" : "");
      d.textContent = String(v.no);
      d.title = v.name;
      d.onclick = function () {
        ensureVol(v.no, function () {
          toast("已载入：" + v.name);
          render(0);
          openMenu();
        });
      };
      box.appendChild(d);
    });
  }

  function openMenu() {
    var b = $("menu-body");
    b.innerHTML = "";
    buildVolTabs($("menu-vols"));
    $("menu-tip").textContent = "当前：" + (META.volume || "") +
      "　共 " + CHAPS.length + " 章　（上方数字可换卷，灰色章节 = 还没读到）";
    CHAPS.forEach(function (c) {
      var d = document.createElement("div");
      d.className = "ch-item" + (S.maxRead >= c.at ? " read" : "");
      var l = document.createElement("span"); l.textContent = c.title;
      var n = document.createElement("span");
      n.className = "n"; n.textContent = String(c.no);
      d.appendChild(n); d.appendChild(l);
      d.onclick = function () { setMood(c.mood); render(c.at); closeAll(); };
      b.appendChild(d);
    });
    $("menupanel").classList.remove("hide");
  }

  /* 名场面回想：每章挑一个冲击帧 + 全部魔纹鉴定，只列已读到的 */
  function buildRecall() {
    var out = [];
    CHAPS.forEach(function (c, idx) {
      var stop = (CHAPS[idx + 1] ? CHAPS[idx + 1].at : NODES.length);
      var best = -1, bl = -1;
      for (var j = c.at; j < Math.min(stop, c.at + 600); j++) {
        var n = NODES[j];
        if (n.t === "i") {
          out.push({ at: j, tag: "鉴定", head: "魔纹鉴定 · " + (n.x[0] || ""), x: n.x.join("　") });
        } else if (n.t === "m" && n.x.length > bl) { bl = n.x.length; best = j; }
      }
      if (best >= 0) {
        out.push({ at: best, tag: "冲击", head: "第 " + c.no + " 章 · " + c.title, x: NODES[best].x });
      }
    });
    out.sort(function (a, b) { return a.at - b.at; });
    return out.filter(function (o) { return o.at <= S.maxRead; });
  }
  function openRecall() {
    var b = $("recall-body"), list = buildRecall();
    b.innerHTML = "";
    if (!list.length) {
      b.innerHTML = '<p class="tiny">这一卷还没有已读到的名场面。继续往下读，冲击帧与魔纹鉴定会自动进到这里。</p>';
    } else {
      list.forEach(function (o) {
        var d = document.createElement("div");
        d.className = "rec-item" + (o.tag === "鉴定" ? " idt" : "");
        var h = document.createElement("div"); h.className = "rec-h";
        h.innerHTML = '<span class="rec-tag">' + esc(o.tag) + '</span>' + esc(o.head);
        var x = document.createElement("div"); x.className = "rec-x"; x.textContent = o.x;
        d.appendChild(h); d.appendChild(x);
        d.onclick = function () {
          savePos();
          render(o.at);
          closeAll();
        };
        b.appendChild(d);
      });
    }
    $("recallpanel").classList.remove("hide");
  }

  /* 快速存档（F5 / F9），独立于 6 个手动槽 */
  var QUICK = "mofan-vn-quick";
  function snap() {
    var ch = curChapter(), n = NODES[S.i];
    return {
      vol: S.vol, i: S.i, ch: ch ? ch.no : 0, chTitle: ch ? ch.title : "",
      text: String(n ? (n.t === "i" ? n.x.join(" ") : n.x) : "").slice(0, 42),
      ts: ""
    };
  }
  function quickSave() {
    if (!NODES.length) { toast("还没开始"); return; }
    try { localStorage.setItem(QUICK, JSON.stringify(snap())); } catch (e) {}
    toast("快速存档 · 第 " + S.vol + " 卷 第 " + (curChapter() || {}).no + " 章");
    beep(1046, 0.12, "sine", 0.035);
  }
  function quickLoad() {
    var q = null;
    try { q = JSON.parse(localStorage.getItem(QUICK) || "null"); } catch (e) {}
    if (!q) { toast("还没有快速存档（F5）"); return; }
    jumpTo(q, "快速读档");
  }
  function getQuick() {
    try { return JSON.parse(localStorage.getItem(QUICK) || "null"); } catch (e) { return null; }
  }

  /* 从存档点跳过去：先关面板/封面，必要时换卷，再渲染 */
  function jumpTo(rec, label) {
    closeAll();
    hideTitle();
    var go = function () {
      render(rec.i);
      toast((label || "读档") + "：第 " + rec.vol + " 卷 第 " + (rec.ch || "?") + " 章");
    };
    if (S.vol !== rec.vol || !NODES.length) ensureVol(rec.vol, go);
    else go();
  }

  function openSave(fromTitle) {
    var b = $("save-body");
    b.innerHTML = "";
    var arr = getSaves();
    var here = { vol: S.vol, i: S.i };
    var ch = curChapter();

    /* 快速存档槽 */
    var q = getQuick();
    var qd = document.createElement("div");
    qd.className = "sv-item quick" + (q ? "" : " empty");
    var qno = document.createElement("div"); qno.className = "sv-no"; qno.textContent = "快速";
    var qmid = document.createElement("div"); qmid.className = "sv-mid";
    qmid.innerHTML = q
      ? '<div class="sv-t">第 ' + q.vol + " 卷 · 第 " + q.ch + " 章 " + esc(q.chTitle || "") + '</div>' +
        '<div class="sv-x">' + esc(q.text || "") + '</div>'
      : '<div class="sv-t">（空）　F5 可随时快速存档</div>';
    var qops = document.createElement("div"); qops.className = "sv-ops";
    var qb1 = document.createElement("button"); qb1.className = "tb"; qb1.textContent = "存";
    qb1.disabled = !!fromTitle;
    qb1.onclick = function () { quickSave(); openSave(fromTitle); };
    var qb2 = document.createElement("button"); qb2.className = "tb"; qb2.textContent = "读";
    qb2.disabled = !q;
    qb2.onclick = function () { jumpTo(q, "快速读档"); };
    qops.appendChild(qb1); qops.appendChild(qb2);
    qd.appendChild(qno); qd.appendChild(qmid); qd.appendChild(qops);
    b.appendChild(qd);

    for (var k = 0; k < 6; k++) {
      (function (k) {
        var rec = arr[k];
        var d = document.createElement("div");
        d.className = "sv-item" + (rec ? "" : " empty");
        var no = document.createElement("div"); no.className = "sv-no"; no.textContent = "槽 " + (k + 1);
        var mid = document.createElement("div"); mid.className = "sv-mid";
        if (rec) {
          mid.innerHTML = '<div class="sv-t">' + "第 " + rec.vol + " 卷 · " +
                          (rec.ch ? ("第 " + rec.ch + " 章 " + esc(rec.chTitle || "")) : "") + '</div>' +
                          '<div class="sv-x">' + esc(rec.text || "") + '</div>' +
                          '<div class="sv-d">' + esc(rec.ts || "") + '</div>';
        } else {
          mid.innerHTML = '<div class="sv-t">（空）</div>';
        }
        var ops = document.createElement("div"); ops.className = "sv-ops";
        var bs = document.createElement("button"); bs.className = "tb"; bs.textContent = "存";
        bs.disabled = !!fromTitle || !NODES.length;
        bs.onclick = function () { doSave(k, here, ch); openSave(fromTitle); };
        var bl = document.createElement("button"); bl.className = "tb"; bl.textContent = "读";
        bl.disabled = !rec;
        bl.onclick = function () { if (rec) jumpTo(rec, "读档"); };
        var bd = document.createElement("button"); bd.className = "tb"; bd.textContent = "删";
        bd.disabled = !rec;
        bd.onclick = function () { arr[k] = null; putSaves(arr); openSave(fromTitle); };
        ops.appendChild(bs); ops.appendChild(bl); ops.appendChild(bd);
        d.appendChild(no); d.appendChild(mid); d.appendChild(ops);
        b.appendChild(d);
      })(k);
    }
    $("savepanel").classList.remove("hide");
  }
  function doSave(k, here, ch) {
    var n = NODES[here.i];
    var txt = n ? (n.t === "i" ? n.x.join(" ") : n.x) : "";
    var arr = getSaves();
    var d = new Date();
    arr[k] = {
      vol: here.vol, i: here.i, ch: ch ? ch.no : 0,
      chTitle: ch ? ch.title : "", text: String(txt).slice(0, 42),
      ts: d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" +
          ("0" + d.getDate()).slice(-2) + " " + ("0" + d.getHours()).slice(-2) + ":" +
          ("0" + d.getMinutes()).slice(-2)
    };
    putSaves(arr);
    toast("已存到槽 " + (k + 1));
    beep(1046, 0.12, "sine", 0.035);
  }
  function closeAll() {
    ["logpanel", "menupanel", "recallpanel", "savepanel", "setpanel", "editpanel"]
      .forEach(function (x) { $(x).classList.add("hide"); });
  }
  var anyOpen = function () {
    return ["logpanel", "menupanel", "recallpanel", "savepanel", "setpanel", "editpanel"]
      .some(function (x) { return !$(x).classList.contains("hide"); });
  };

  /* ================= 改写面板 ================= */
  var TYPE_NAME = { n: "旁白", d: "对话", m: "冲击帧", p: "关键物", c: "章节卡", i: "魔纹鉴定" };

  function openEdit() {
    if (!NODES.length) { toast("先进入正文再改写"); return; }
    var n = NODES[S.i];
    if (!n || n.t === "c" || n.t === "i") { toast("章节卡 / 鉴定面板不支持改写"); return; }
    var vk = vkey(S.vol);
    $("ed-where").textContent = "第 " + S.vol + " 卷　节点 #" + S.i +
      "　当前：" + (TYPE_NAME[n.t] || n.t) + (n.w ? "（" + n.w + "）" : "");
    $("ed-t").value = n.t;
    $("ed-x").value = (n.t === "i") ? n.x.join("\n") : String(n.x || "");
    $("ed-w").value = n.w || "";
    $("ed-fx").value = n.e || "";
    $("ed-w-row").style.display = (n.t === "d") ? "" : "none";
    $("ed-tip").textContent = "本机已存 " + countEdits() + " 条改写。" +
      "改完点「保存」立刻生效；点「导出」可拿到能粘进 spec/patch.json 的规则，让 PC / 手机 / 分发包 / 千星移植版一起生效。";
    $("editpanel").classList.remove("hide");
  }
  function closeEdit() { $("editpanel").classList.add("hide"); }

  function bindEdit() {
    $("ed-t").onchange = function () {
      $("ed-w-row").style.display = (this.value === "d") ? "" : "none";
    };
    $("ed-save").onclick = function () {
      var n = NODES[S.i];
      if (!n) return;
      var x0 = n.x;
      var t = $("ed-t").value;
      var f = { t: t, x: $("ed-x").value };
      if (t === "d") f.w = $("ed-w").value.trim();
      else f.w = "";                       // 非对话清掉说话人
      f.e = $("ed-fx").value;
      saveEdit(vkey(S.vol), S.i, f, x0);
      // 立刻就地生效（下次打开时由 applyPatch 从 localStorage 还原）
      Object.keys(f).forEach(function (k) {
        if (f[k] === "" || f[k] === null) delete n[k]; else n[k] = f[k];
      });
      closeEdit();
      render(S.i);
      toast("已改写 #" + S.i + "（本机 " + countEdits() + " 条）");
    };
    $("ed-revert").onclick = function () {
      var vk = vkey(S.vol), e = getEdits();
      var before = (e[vk] || []).length;
      e[vk] = (e[vk] || []).filter(function (r) { return r.at !== S.i; });
      putEdits(e);
      closeEdit();
      if ((e[vk] || []).length === before) { toast("这一页没有改写记录"); return; }
      toast("已恢复本页原文，正在重载…");
      setTimeout(function () { location.reload(); }, 600);
    };
    $("ed-clear").onclick = function () {
      if (!countEdits()) { toast("还没有改写记录"); return; }
      clearEdits();
      toast("已清空全部改写，正在重载…");
      setTimeout(function () { location.reload(); }, 600);
    };
    $("ed-export").onclick = function () {
      var e = getEdits();
      if (!countEdits()) { toast("还没有改写记录可导出"); return; }
      var out = {}, n = 0;
      Object.keys(e).forEach(function (vk) {
        // 用 x0（原文快照）定位，比按下标稳：重新切页后下标会漂移
        var list = (e[vk] || []).map(function (r) {
          n++;
          return { x0: r.x0, op: "set", set: r.set };
        });
        if (list.length) out[vk] = list;
      });
      var txt = JSON.stringify(out, null, 2);
      try {
        var blob = new Blob([txt], { type: "application/json" });
        var a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "patch.json";
        document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
        toast("已导出 " + n + " 条规则 → patch.json");
      } catch (err) {
        console.log(txt);
        toast("浏览器不让下载，已打印到控制台 (F12)");
      }
    };
  }

  /* ================= 事件 ================= */
  document.addEventListener("keydown", function (e) {
    if (e.target && e.target.tagName === "INPUT") return;
    if (!$("titlecard").classList.contains("hide")) {
      if (e.key === "Escape") { closePick(); $("savepanel").classList.add("hide"); }
      return;
    }
    switch (e.key) {
      case "F5": e.preventDefault(); quickSave(); return;
      case "F9": e.preventDefault(); quickLoad(); return;
      case " ": case "Enter": case "ArrowRight": case "ArrowDown":
        e.preventDefault(); advance(); break;
      case "ArrowLeft": case "ArrowUp": back(); break;
      case "a": case "A": toggleAuto(); break;
      case "s": case "S": skipRead(); break;
      case "h": case "H": openLog(); break;
      case "m": case "M": openMenu(); break;
      case "r": case "R": openRecall(); break;
      case "v": case "V": openSave(); break;
      case "e": case "E": openEdit(); break;
      case "o": case "O": $("setpanel").classList.remove("hide"); break;
      case "f": case "F":
        if (document.fullscreenElement) document.exitFullscreen();
        else document.documentElement.requestFullscreen();
        break;
      case "Escape": closeAll(); break;
    }
  });
  document.addEventListener("wheel", function (e) {
    if (e.deltaY >= -40) return;
    if (anyOpen()) return;
    back();
  }, { passive: true });

  /* ---------- 触摸手势（手机 / 平板） ---------- */
  function bindTouch() {
    var el = $("reader");
    if (!el || !window.addEventListener) return;
    var sx = 0, sy = 0, moved = false;
    var MIN = 46;                       // 判定为滑动的最小位移
    el.addEventListener("touchstart", function (e) {
      if (e.touches.length !== 1) return;
      sx = e.touches[0].clientX; sy = e.touches[0].clientY; moved = false;
    }, { passive: true });
    el.addEventListener("touchmove", function (e) {
      if (!e.touches.length) return;
      var dx = e.touches[0].clientX - sx, dy = e.touches[0].clientY - sy;
      if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true;
    }, { passive: true });
    el.addEventListener("touchend", function (e) {
      if (!moved || anyOpen()) return;   // 没动 = 普通点击，交给 onclick
      var t = e.changedTouches[0];
      var dx = t.clientX - sx, dy = t.clientY - sy;
      if (Math.abs(dx) > Math.abs(dy)) {
        if (Math.abs(dx) > MIN) { if (dx < 0) advance(); else back(); }
      } else if (dy < -70) { openMenu(); }
      else if (dy > 70) { openLog(); }
    });
  }

  /* ---------- 移动端底部条 ---------- */
  function bindMobileBar() {
    var map = {
      "mb-menu": openMenu, "mb-log": openLog, "mb-skip": skipRead,
      "mb-save": function () { openSave(false); }, "mb-back": back,
      "mb-edit": openEdit
    };
    Object.keys(map).forEach(function (id) {
      var b = $(id);
      if (b) b.onclick = map[id];
    });
    var a = $("mb-auto");
    if (a) a.onclick = function () { toggleAuto(); a.classList.toggle("on", S.auto); };
  }

  function bindUI() {
    bindTouch();
    bindMobileBar();
    $("btn-auto").onclick = function () { toggleAuto(); };
    $("btn-skip").onclick = skipRead;
    $("btn-log").onclick = openLog;
    $("btn-menu").onclick = openMenu;
    $("btn-recall").onclick = openRecall;
    $("btn-save").onclick = openSave;
    $("btn-edit").onclick = openEdit;
    $("btn-set").onclick = function () { $("setpanel").classList.remove("hide"); };
    bindEdit();

    ["logpanel", "menupanel", "recallpanel", "savepanel", "setpanel", "editpanel"].forEach(function (x) {
      $(x).onclick = function (e) { if (e.target === this) this.classList.add("hide"); };
    });

    $("s-size").oninput = function () { S.size = +this.value; applySet(); savePref(); };
    $("s-line").oninput = function () { S.line = +this.value; applySet(); savePref(); };
    $("s-speed").oninput = function () { S.speed = +this.value; applySet(); savePref(); };
    $("s-type").onchange = function () { S.typewriter = this.checked; savePref(); };
    $("s-name").onchange = function () { S.showName = this.checked; savePref(); render(S.i); };
    $("s-cast").onchange = function () { S.cast = this.checked; savePref(); renderCast(curSpeaker()); };
    $("s-sound").onchange = function () { S.sound = this.checked; savePref(); if (S.sound) beep(880, 0.1, "sine", 0.03); };
    $("s-theme").onclick = function () { S.theme = (S.theme === "ink" ? "paper" : "ink"); applySet(); savePref(); };
  }
  function curSpeaker() {
    var n = NODES[S.i];
    return (n && n.t === "d") ? n.w : null;
  }

  /* ================= 卷首 ================= */
  var pickVol = 1;

  function buildTitle() {
    $("mi-start").onclick = function () { jumpTo({ vol: 1, i: 0, ch: 1 }, "从头开始"); };
    $("mi-load").onclick = function () { openSave(true); };
    $("mi-chap").onclick = openPick;
    $("mi-quit").onclick = function () {
      $("quitmask").classList.remove("hide");
      try { window.close(); } catch (e) {}
    };
    $("qm-back").onclick = function () { $("quitmask").classList.add("hide"); };
    $("pick-back").onclick = closePick;
  }

  /* 章节选择：二级页面，不在封面首屏 */
  function openPick() {
    if (!NODES.length) { ensureVol(pickVol, openPick); return; }
    $("tc-menu").classList.add("hide");
    $("tc-resume").classList.add("hide");
    $("tc-tip").classList.add("hide");
    $("tc-pick").classList.remove("hide");

    var pv = $("pick-vols");
    pv.innerHTML = "";
    (TOC.volumes || []).forEach(function (v) {
      var b = document.createElement("button");
      b.className = "voltab" + (v.no === S.vol ? " on" : "");
      b.textContent = String(v.no);
      b.title = v.name;
      b.onclick = function () { pickVol = v.no; ensureVol(v.no, openPick); };
      pv.appendChild(b);
    });

    var pc = $("pick-chaps");
    pc.innerHTML = "";
    $("pick-tip").textContent = (META.volume || "") + "　共 " + CHAPS.length + " 章";
    CHAPS.forEach(function (c) {
      var d = document.createElement("div");
      d.className = "ch-item";
      var no = document.createElement("span"); no.className = "n"; no.textContent = String(c.no);
      var t = document.createElement("span"); t.textContent = c.title;
      d.appendChild(no); d.appendChild(t);
      d.onclick = function () {
        var v = S.vol, at = c.at, mood = c.mood;
        closePick();
        hideTitle();
        setMood(mood);
        render(at);
        toast("第 " + v + " 卷 · 第 " + c.no + " 章");
      };
      pc.appendChild(d);
    });
  }
  function closePick() {
    $("tc-pick").classList.add("hide");
    $("tc-menu").classList.remove("hide");
    $("tc-tip").classList.remove("hide");
    if (!$("tc-resume").dataset.off) $("tc-resume").classList.remove("hide");
  }

  function hideTitle() {
    $("titlecard").classList.add("hide");
    setTimeout(function () { $("titlecard").style.display = "none"; }, 700);
  }
  function startVol(v, at) {
    var go = function () {
      hideTitle();
      setMood("toilet");
      var ch = null;
      for (var i = 0; i < CHAPS.length; i++) { if (CHAPS[i].at <= at) ch = CHAPS[i]; else break; }
      if (ch) setMood(ch.mood);
      render(at);
    };
    if (S.vol === v && NODES.length) go();
    else ensureVol(v, go);
  }

  /* ================= 启动 ================= */
  var VN = {
    advance: advance,
    sprite: spriteSVG,          /* 供冒烟测试/调试用 */
    param: param,
    closeLog: function () { $("logpanel").classList.add("hide"); },
    closeMenu: function () { $("menupanel").classList.add("hide"); },
    closeRecall: function () { $("recallpanel").classList.add("hide"); },
    closeSave: function () { $("savepanel").classList.add("hide"); },
    closeSet: function () { $("setpanel").classList.add("hide"); },
    closeEdit: closeEdit,
    /* ---- 改写 / 更新接口（给外部脚本或后续 AI 用） ---- */
    edit: {
      open: openEdit,
      apply: applyPatch,
      rules: function (vol) { return rulesFor("vol" + (vol < 10 ? "0" : "") + vol); },
      all: function () { return getEdits(); },
      add: function (vol, rule) {                       /* VN.edit.add(1,{find:"XX",op:"demote"}) */
        var vk = "vol" + (vol < 10 ? "0" : "") + vol, e = getEdits();
        (e[vk] = e[vk] || []).push(rule);
        putEdits(e);
        delete PATCHED[vk];
        return (e[vk] || []).length;
      },
      clear: function (vol) {
        clearEdits(vol ? ("vol" + (vol < 10 ? "0" : "") + vol) : null);
      },
      count: countEdits
    }
  };
  window.VN = VN;

  function boot() {
    var isTouch = ("ontouchstart" in window) ||
                  (navigator && navigator.maxTouchPoints > 0);
    loadPref();
    if (isTouch && !localStorage.getItem(PREF)) S.size = 19;   /* 手机默认字大一点 */
    applySet();
    bindUI();
    if (isTouch) document.body.classList.add("is-touch");

    if (!TOC.volumes || !TOC.volumes.length) {
      $("tc-vol").textContent = "assets/toc.js 没读到";
      return;
    }
    buildTitle();

    var pos = null;
    try { pos = JSON.parse(localStorage.getItem(POS) || "null"); } catch (e) {}
    if (pos && pos.vol) {
      $("tc-resume").classList.remove("hide");
      $("tc-at").textContent = "第 " + pos.vol + " 卷 第 " + (pos.ch || "?") + " 章「" +
                               (pos.chTitle || "") + "」";
      $("tc-resume").onclick = function () { jumpTo(pos, "继续"); };
      pickVol = pos.vol;
    } else {
      $("tc-resume").dataset.off = "1";
    }
  }
  boot();
})();
