/* 离线缓存：外壳立刻缓存，卷数据按需缓存 */
const CACHE = "mofan-v1";
const SHELL = ["./", "./mobile.html", "./app.js", "./style.css", "./mobile.css",
  "./manifest.webmanifest", "./icon-192.png", "./icon-512.png",
  "./assets/toc.js", "./assets/names.js", "./assets/sprites.js", "./assets/patch.js"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys()
    .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  const r = e.request;
  if (r.method !== "GET") return;
  e.respondWith(
    caches.match(r).then(hit => {
      if (hit) return hit;
      return fetch(r).then(res => {
        if (res && res.status === 200 && res.type === "basic") {
          const cp = res.clone();
          caches.open(CACHE).then(c => c.put(r, cp));
        }
        return res;
      }).catch(() => caches.match("./mobile.html"));
    })
  );
});
